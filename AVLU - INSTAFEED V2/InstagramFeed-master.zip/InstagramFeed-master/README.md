# InstagramFeed [![Build Status](https://travis-ci.com/jsanahuja/InstagramFeed.svg?branch=master)](https://travis-ci.com/jsanahuja/InstagramFeed)
Instagram Feed without using the instagram API. Neither jQuery!

This is a vanilla JavaScript version of the original [jquery.instagramFeed](https://github.com/jsanahuja/jquery.instagramFeed)

[Full documentation and examples here](https://www.sowecms.com/demos/InstagramFeed)
